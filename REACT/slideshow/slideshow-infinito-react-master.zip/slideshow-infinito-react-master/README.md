# Crea un Slideshow Infinito, Animado y Reutilizable desde Cero con React
### [Tutorial: https://youtu.be/q00ldTrywLU ](https://youtu.be/q00ldTrywLU )

![Crea un Slideshow Infinito, Animado y Reutilizable desde Cero con React](https://raw.githubusercontent.com/falconmasters/slideshow-infinito-react/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)